package br.com.rc.demoschedule.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import br.com.rc.demoschedule.config.ScheduleConfig;

@Service
public class ScheduleService {
	
	private static final Logger log = LoggerFactory.getLogger(ScheduleConfig.class);
	 
	public void writeLog() {
		log.info("Escrevendo em um tempo paramatezavel");
	}
}
