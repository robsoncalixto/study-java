package com.exemplo.rest.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.Builder;

import com.exemplo.rest.model.Quote;

import reactor.core.publisher.Mono;

@Service
public class RestWebClientService {

	private static final Logger log = LoggerFactory.getLogger(RestWebClientService.class);

	public Quote retornaQuote() {
		// Forma completa usando o Builder
		Builder  builder = WebClient.builder();
		Mono<Quote> monoQuote1 = builder.baseUrl("https://gturnquist-quoters.cfapps.io/api")
								   .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
								   .build()
								   .method(HttpMethod.GET)
								   .uri("/random")
								   .retrieve()
								   .bodyToMono(Quote.class)
								   ;
		
	    monoQuote1.subscribe(quote -> {
	    	log.info("Depois aqui...");
	    	log.info("Monstrando quote dentro do subscribe: "+quote.toString());
	    });
	    
	    log.info("Vai passar primeiro aqui porque o webclinte é não bloqueante...");
	    
		Quote quote1 = monoQuote1.block();
		log.info("Mostrando quote1 usando WebClient.builder(): "+quote1.toString());
		
		// Forma simplificada
		long start = System.currentTimeMillis();
		WebClient webClient =
		WebClient.create("https://gturnquist-quoters.cfapps.io/api/random");
		Mono<Quote> monoQuote2 = webClient.get().retrieve().bodyToMono(Quote.class);
		Quote quote2 = monoQuote2.block(); 
		log.info("Mostrando quote2 WebClient.create(): "+quote2.toString());
		long elapsed = System.currentTimeMillis() - start;
		log.info("Tempo gasto em milisegundos: "+Long.toString(elapsed));
		
	    return quote1;

	}

	public List<Quote> retornaQuotes() {
		long start = System.currentTimeMillis();
		
		List<Quote> quotes = new ArrayList<Quote>();
		
		WebClient webClient = WebClient.create("https://gturnquist-quoters.cfapps.io/api/random");
		Mono<Quote> monoQuote1 = webClient.get().retrieve().bodyToMono(Quote.class);
		Mono<Quote> monoQuote2 = webClient.get().retrieve().bodyToMono(Quote.class);
		
		// Inicialmente poderíamos chamar o block() como estou fazendo abaixo porém isso acaba bloqueando as requisições e não usando o recurso não bloqueando, que é justamente o que queremos.
		//Quote quote1 = monoQuote1.block(); 
		//Quote quote2 = monoQuote2.block();
		
		// Para resolver esse problema precisamos usar o método zip e depois o block para obtermos a resposta do nosso objeto Quote.
		quotes = Mono.zip(monoQuote1, monoQuote2).map(tuple -> {
			return Arrays.asList(tuple.getT1(), tuple.getT2());
		}).block();
		
		long elapsed = System.currentTimeMillis() - start;
 		
		log.info("Tempo gasto em milisegundos: "+Long.toString(elapsed));
		
	    return quotes;		
	}

	public String postJsonQualquer(String jsonQualquer) {
		long start = System.currentTimeMillis();
		
		// Exemplo de como usar o POST.
		WebClient webClient = WebClient.create("https://jsonplaceholder.typicode.com/posts");
		Mono<String> mono = webClient.post().uri("/").body(BodyInserters.fromValue(jsonQualquer)).retrieve().bodyToMono(String.class);
		String jsonGravado = mono.block(); 
		log.info("Mostrando json retornado por jsonplaceholder: "+jsonGravado.toString());
		
		long elapsed = System.currentTimeMillis() - start;
		
		log.info("Tempo gasto em milisegundos: "+Long.toString(elapsed));
		
	    return jsonGravado;
	}

}
