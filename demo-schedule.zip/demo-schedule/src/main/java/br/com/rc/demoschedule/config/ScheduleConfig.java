package br.com.rc.demoschedule.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import br.com.rc.demoschedule.service.ScheduleService;


@Component
@EnableScheduling
public class ScheduleConfig {
	
	@Autowired
	private ScheduleService cservice;
	
	 
	@Scheduled(fixedDelay = 5000)
	public void writelog() {
	
		cservice.writeLog();
	}
}
