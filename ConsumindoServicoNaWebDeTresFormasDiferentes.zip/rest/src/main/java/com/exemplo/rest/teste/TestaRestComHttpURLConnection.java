package com.exemplo.rest.teste;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import com.exemplo.rest.model.Quote;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestaRestComHttpURLConnection {

	
	private static final Logger log = LoggerFactory.getLogger(TestaRestComHttpURLConnection.class);

	public static void main(String[] args) {
		try {
			URL url = new URL("https://gturnquist-quoters.cfapps.io/api/random");
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod(HttpMethod.GET.toString());
			conn.setRequestProperty(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON.toString());
			conn.setRequestProperty(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON.toString());
			if(conn.getResponseCode() != 200) {
				throw new RuntimeException("Falha ao acessar a url "+url.getContent()+". Statuscode: "+conn.getResponseCode());
			}
			
			InputStreamReader in = new InputStreamReader(conn.getInputStream());
			BufferedReader br = new BufferedReader(in);
			String input;
			input = br.readLine();
			conn.disconnect();
			
			ObjectMapper mapper = new ObjectMapper();
			Quote quote = mapper.readValue(input, Quote.class);
			log.info(quote.toString());
		} catch (Exception e) {
			log.info(e.getMessage());
		}
	}
}
