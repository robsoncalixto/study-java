package com.exemplo.rest.teste;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.client.RestTemplate;

import com.exemplo.rest.model.Quote;

public class TestaRestTemplate {

	
	private static final Logger log = LoggerFactory.getLogger(TestaRestTemplate.class);

	public static void main(String[] args) {
		RestTemplate rest = new RestTemplateBuilder().build();
		Quote quote = rest.getForObject("https://gturnquist-quoters.cfapps.io/api/random", 
				Quote.class);
		log.info(quote.toString());
	}
}
