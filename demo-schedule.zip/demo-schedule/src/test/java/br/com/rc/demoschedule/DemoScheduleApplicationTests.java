package br.com.rc.demoschedule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoScheduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
