package com.exemplo.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exemplo.rest.model.Quote;
import com.exemplo.rest.service.RestWebClientService;

@RestController
public class RestWebClientController {
	
	@Autowired
	private RestWebClientService restService;

	@GetMapping("/unico")
	public Quote mostraChamadaUnicaDoQuote() {
		
		return restService.retornaQuote();
	}

	@GetMapping("/duplo")
	public List<Quote> mostraChamadaEmParaleloQuote() {
		
		return restService.retornaQuotes();
	}
	
	@PostMapping
	// Eu não criei uma Entity para receber o json enviado por isso usei o ResponseEntity<?>.
	public ResponseEntity<?> gravaAPIFake(@RequestBody String jsonQualquer){
		String jonGravado = restService.postJsonQualquer(jsonQualquer);
		return ResponseEntity.status(HttpStatus.CREATED).body(jonGravado);
	}
}
