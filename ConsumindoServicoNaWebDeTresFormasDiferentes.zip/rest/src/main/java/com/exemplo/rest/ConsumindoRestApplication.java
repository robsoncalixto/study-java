package com.exemplo.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumindoRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumindoRestApplication.class, args);
	}	
}
