package br.com.rc.demoschedule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoScheduleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoScheduleApplication.class, args);
	}

}
